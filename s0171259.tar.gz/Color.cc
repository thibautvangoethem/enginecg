/*
 * Color.cpp
 *
 *  Created on: Feb 20, 2018
 *      Author: thibaut
 */

#include "Color.h"

