/*
 * Point2D.cpp
 *
 *  Created on: Feb 20, 2018
 *      Author: thibaut
 */

#include "Point2D.h"

double Point2D::getx(){
	double X=Point2D::x;
	return X;
}
double Point2D::gety(){
	double Y=Point2D::y;
	return Y;
}




